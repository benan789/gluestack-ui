import React from 'react';
export declare function ActionsheetSectionList<P>(StyledActionsheetSectionList: React.ComponentType<P>): React.ForwardRefExoticComponent<React.PropsWithoutRef<React.PropsWithoutRef<P>> & React.RefAttributes<any>>;
//# sourceMappingURL=ActionsheetSectionList.d.ts.map