import React from 'react';
export declare function ActionsheetVirtualizedList<P>(StyledActionsheetVirtualizedList: React.ComponentType<P>): React.ForwardRefExoticComponent<React.PropsWithoutRef<React.PropsWithoutRef<P>> & React.RefAttributes<any>>;
//# sourceMappingURL=ActionsheetVirtualizedList.d.ts.map