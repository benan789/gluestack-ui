import React from 'react';
export declare function ActionsheetFlatList<P>(StyledActionsheetFlatList: React.ComponentType<P>): React.ForwardRefExoticComponent<React.PropsWithoutRef<React.PropsWithoutRef<P>> & React.RefAttributes<any>>;
//# sourceMappingURL=ActionsheetFlatList.d.ts.map