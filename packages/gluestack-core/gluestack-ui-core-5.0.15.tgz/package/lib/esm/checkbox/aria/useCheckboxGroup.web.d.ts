import { AriaCheckboxGroupProps } from '@react-types/checkbox';
import { CheckboxGroupState } from '@react-stately/checkbox';
interface CheckboxGroupAria {
    /** Props for the checkbox group wrapper element. */
    groupProps: any;
    /** Props for the checkbox group's visible label (if any). */
    labelProps: any;
}
/**
 * Provides the behavior and accessibility implementation for a checkbox group component.
 * Checkbox groups allow users to select multiple items from a list of options.
 * @param props - Props for the checkbox group.
 * @param state - State for the checkbox group, as returned by `useCheckboxGroupState`.
 */
export declare function useCheckboxGroup(props: AriaCheckboxGroupProps, state: CheckboxGroupState): CheckboxGroupAria;
export {};
//# sourceMappingURL=useCheckboxGroup.web.d.ts.map