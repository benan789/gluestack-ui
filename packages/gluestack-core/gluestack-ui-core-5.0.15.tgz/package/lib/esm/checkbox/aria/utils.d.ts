import { CheckboxGroupState } from '@react-stately/checkbox';
export declare const checkboxGroupNames: WeakMap<CheckboxGroupState, string>;
//# sourceMappingURL=utils.d.ts.map