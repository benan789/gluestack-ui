import type { AriaMenuProps } from '@react-types/menu';
import type { RefObject } from 'react';
import type { KeyboardDelegate } from '@react-types/shared';
import type { TreeState } from '@react-stately/tree';
import type { AccessibilityProps } from 'react-native';
interface MenuAria {
    /** Props for the menu element. */
    menuProps: AccessibilityProps;
}
interface AriaMenuOptions<T> extends AriaMenuProps<T> {
    /** Whether the menu uses virtual scrolling. */
    isVirtualized?: boolean;
    /**
     * An optional keyboard delegate implementation for type to select,
     * to override the default.
     */
    keyboardDelegate?: KeyboardDelegate;
}
/**
 * Provides the behavior and accessibility implementation for a menu component.
 * A menu displays a list of actions or options that a user can choose.
 * @param props - Props for the menu.
 * @param state - State for the menu, as returned by `useListState`.
 */
export declare function useMenu<T>(_props: AriaMenuOptions<T>, _state: TreeState<T>, _ref: RefObject<HTMLElement>): MenuAria;
export {};
//# sourceMappingURL=useMenu.d.ts.map