import { ReactNode } from 'react';
interface AriaMenuSectionProps {
    /** The heading for the section. */
    'heading'?: ReactNode;
    /** An accessibility label for the section. Required if `heading` is not present. */
    'aria-label'?: string;
}
interface MenuSectionAria {
    /** Props for the wrapper list item. */
    itemProps: any;
    /** Props for the heading element, if any. */
    headingProps: any;
    /** Props for the group element. */
    groupProps: any;
}
/**
 * Provides the behavior and accessibility implementation for a section in a menu.
 * See `useMenu` for more details about menus.
 * @param props - Props for the section.
 */
export declare function useMenuSection(props: AriaMenuSectionProps): MenuSectionAria;
export {};
//# sourceMappingURL=useMenuSection.d.ts.map