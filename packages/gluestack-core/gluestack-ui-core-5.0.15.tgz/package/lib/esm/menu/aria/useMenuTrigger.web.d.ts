import { RefObject } from 'react';
import type { MenuTriggerState } from '@react-stately/menu';
interface MenuTriggerAriaProps {
    /** The type of menu that the menu trigger opens. */
    type?: 'menu' | 'listbox';
}
interface MenuTriggerAria {
    /** Props for the menu trigger element. */
    menuTriggerProps: any;
    /** Props for the menu. */
    menuProps: any;
}
/**
 * Provides the behavior and accessibility implementation for a menu trigger.
 * @param props - Props for the menu trigger.
 * @param state - State for the menu trigger.
 */
export declare function useMenuTrigger(props: MenuTriggerAriaProps, state: MenuTriggerState, ref: RefObject<HTMLElement>): MenuTriggerAria;
export {};
//# sourceMappingURL=useMenuTrigger.web.d.ts.map