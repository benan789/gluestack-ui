import { Key, RefObject } from 'react';
import { TreeState } from '@react-stately/tree';
import { ViewProps } from 'react-native';
interface MenuItemAria {
    /** Props for the menu item element. */
    menuItemProps: ViewProps;
    /** Props for the main text element inside the menu item. */
    labelProps: ViewProps;
    /** Props for the description text element inside the menu item, if any. */
    descriptionProps: ViewProps;
    /** Props for the keyboard shortcut text element inside the item, if any. */
    keyboardShortcutProps: ViewProps;
}
interface AriaMenuItemProps {
    /** Whether the menu item is disabled. */
    'isDisabled'?: boolean;
    /** Whether the menu item is selected. */
    'isSelected'?: boolean;
    /** A screen reader only label for the menu item. */
    'aria-label'?: string;
    /** The unique key for the menu item. */
    'key'?: any;
    /** Handler that is called when the menu should close after selecting an item. */
    'onClose'?: () => void;
    /**
     * Whether the menu should close when the menu item is selected.
     * @default true
     */
    'closeOnSelect'?: boolean;
    /** Whether the menu item is contained in a virtual scrolling menu. */
    'isVirtualized'?: boolean;
    /** Handler that is called when the user activates the item. */
    'onAction'?: (key: Key) => void;
}
/**
 * Provides the behavior and accessibility implementation for an item in a menu.
 * See `useMenu` for more details about menus.
 * @param props - Props for the item.
 * @param state - State for the menu, as returned by `useTreeState`.
 */
export declare function useMenuItem<T>(props: AriaMenuItemProps, state: TreeState<T>, ref: RefObject<HTMLElement>): MenuItemAria;
export {};
//# sourceMappingURL=useMenuItem.web.d.ts.map