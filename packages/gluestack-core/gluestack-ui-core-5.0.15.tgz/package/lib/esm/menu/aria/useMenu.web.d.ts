import { AriaMenuOptions } from '@react-aria/menu';
import { TreeState } from '@react-stately/tree';
import { RefObject } from 'react';
export declare const useMenu: (props: AriaMenuOptions<unknown>, state: TreeState<unknown>, ref: RefObject<any>) => import("@react-aria/menu").MenuAria;
//# sourceMappingURL=useMenu.web.d.ts.map