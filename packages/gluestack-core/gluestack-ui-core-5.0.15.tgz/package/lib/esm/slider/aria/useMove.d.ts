interface MoveResult {
    /** Props to spread on the target element. */
    moveProps: any;
}
/**
 * Handles move interactions across mouse, touch, and keyboard, including dragging with
 * the mouse or touch, and using the arrow keys. Normalizes behavior across browsers and
 * platforms, and ignores emulated mouse events on touch devices.
 */
export declare function useMove(props: any): MoveResult;
export {};
//# sourceMappingURL=useMove.d.ts.map