export declare const useSlider: (props: any, state: any, ref: any, isReversed?: boolean, _trackRef?: unknown) => {
    labelProps: any;
    /** Props for the track element. */
    trackProps: any;
    /** Props for the output element, displaying the value of the slider thumbs. */
    outputProps: any;
    groupProps: any;
};
//# sourceMappingURL=useSlider.web.d.ts.map