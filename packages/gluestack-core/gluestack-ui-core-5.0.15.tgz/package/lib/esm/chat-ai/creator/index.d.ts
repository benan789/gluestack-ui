export declare const createChatAi: () => void;
//# sourceMappingURL=index.d.ts.map